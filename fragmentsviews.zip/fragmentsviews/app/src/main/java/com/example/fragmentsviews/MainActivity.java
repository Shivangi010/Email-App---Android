package com.example.fragmentsviews;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements ListFrag.ItemSelected {

    TextView tvDescription;
    ArrayList<String> descriptions;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvDescription = findViewById(R.id.tvDescription);

        descriptions = new ArrayList<String>();
        descriptions.add("Thank you for your interest in joining Maple.");
        descriptions.add("Unlock your special offer and design like a rockstar with Crello Pro for an entire year.");
        descriptions.add("Your Assessment date has been finalized, we will catch up with same shortly");
    }

    @Override
    public void onItemSelected(int index) {
         tvDescription.setText(descriptions.get(index));
    }
}